package com.demo.batch.model;

import java.math.BigDecimal;

public class Report { 

	private String customerName; 
	private Integer orders = 0; 
	private BigDecimal total = BigDecimal.ZERO;
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Integer getOrders() {
		return orders;
	}
	public void setOrders(Integer orders) {
		this.orders = orders;
	}
	public BigDecimal getTotal() {
		return total;
	}
	public void setTotal(BigDecimal total) {
		this.total = total;
	}
	@Override
	public String toString() {
		return "Report [customerName=" + customerName + ", orders=" + orders + ", total=" + total + "]";
	} 

}
