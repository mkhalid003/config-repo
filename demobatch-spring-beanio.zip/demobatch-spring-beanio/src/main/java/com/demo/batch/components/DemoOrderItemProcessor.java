package com.demo.batch.components;

import javax.batch.api.chunk.ItemProcessor;

import com.demo.batch.model.Customer;
import com.demo.batch.model.Order;
import com.demo.batch.model.Report;

public class DemoOrderItemProcessor implements ItemProcessor { 
	
	private Report report = null; 
	private Report prev = null; 

	@Override
	public Object processItem(Object record) throws Exception { 
		if ( record instanceof Customer ) { 
			prev = report; 
			Customer customer = (Customer) record; 
			report = new Report(); 
			report.setCustomerName( customer.getLastName() ); 
			return prev; 
		} else if ( record instanceof Order) { 
			Order order = (Order) record; 
			report.setOrders( report.getOrders() + 1); 
			report.setTotal( report.getTotal().add( order.getAmount() ) ); 
			return null; 
		} else { 
			return report; 
		} 
	}
}

	