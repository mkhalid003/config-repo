package com.demo.batch.components;

import java.util.List;

import org.springframework.batch.item.ItemWriter;

import com.demo.batch.model.Report;

public class DemoOrderItemWriter implements ItemWriter<Report> {

	StringBuilder text = new StringBuilder();
	
	@Override
	public void write(List<? extends Report> items) throws Exception {

		System.out.println("==== Printing Report ====");
		for (Report report : items) {
			System.out.println(report);
		}
	}

}
