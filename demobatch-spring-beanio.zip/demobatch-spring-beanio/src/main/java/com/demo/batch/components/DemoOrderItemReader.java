package com.demo.batch.components;

import org.beanio.spring.BeanIOFlatFileItemReader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;

import com.demo.batch.model.Order;

public class DemoOrderItemReader {

	@Value("customer-records.csv") 
	Resource resource;
	
	@Value("order-mapping.xml") 
	Resource orderMappingFile;
	
	public BeanIOFlatFileItemReader<Order> read() {
		// TODO Auto-generated method stub
		BeanIOFlatFileItemReader<Order> beanIOFlatFileItemReader = new BeanIOFlatFileItemReader<>();
		beanIOFlatFileItemReader.setResource(resource);
		beanIOFlatFileItemReader.setStreamName("customerOrdersFile");
		beanIOFlatFileItemReader.setStreamMapping(orderMappingFile);
		return beanIOFlatFileItemReader;
	}

}
