package com.example.demo.model;

import java.util.List;

import lombok.Data;

@Data
public class Customer {
    private String firstName;
    private String lastName;
    private List orders;
	@Override
	public String toString() {
		return "Customer [firstName=" + firstName + ", lastName=" + lastName + ", orders=" + orders + "]";
	} 
    
    
}