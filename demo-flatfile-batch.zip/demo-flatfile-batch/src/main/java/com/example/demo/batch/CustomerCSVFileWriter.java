package com.example.demo.batch;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

@Component
public class CustomerCSVFileWriter implements ItemWriter<Object> {


	@Override
	public void write(List<? extends Object> items) throws Exception {

		for (Object object : items) {
			System.out.println(object);
		}
	}
}
