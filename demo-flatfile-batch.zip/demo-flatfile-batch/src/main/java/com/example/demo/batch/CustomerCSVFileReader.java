package com.example.demo.batch;


import org.beanio.StreamFactory;
import org.beanio.spring.BeanIOFlatFileItemReader;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

@Component
public class CustomerCSVFileReader {
	
	@Bean
	public BeanIOFlatFileItemReader<Object> readEPEFile() throws Exception {
		BeanIOFlatFileItemReader<Object> reader = new BeanIOFlatFileItemReader<>();
        reader.setStreamFactory(StreamFactory.newInstance());
        reader.setResource(new ClassPathResource("customer-orders.csv"));
        reader.setStreamMapping(new ClassPathResource("order-mapping.xml"));
        reader.setStreamName("EPE File");
        reader.afterPropertiesSet();
        reader.getLineNumber();
        reader.open(new ExecutionContext());   
		return reader;
	}
}
